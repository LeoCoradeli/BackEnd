const geoLocation = require("nativescript-geolocation");
var frameModule = require("tns-core-modules/ui/frame");
var observableModule = require("tns-core-modules/data/observable");

function HomeViewModel() {
  var viewModel = observableModule.fromObject({
    currentHour: new Date().getHours(),
    currentMinute: new Date().getMinutes(),

    progressValue: 80,

    countries: [
      { name: "Australia", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/au.png" },
      { name: "Belgium", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/be.png" },
      { name: "Bulgaria", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/bg.png" },
      { name: "Canada", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/ca.png" },
      { name: "Switzerland", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/ch.png" },
      { name: "China", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/cn.png" },
      { name: "Czech Republic", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/cz.png" },
      { name: "Germany", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/de.png" },
      { name: "Spain", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/es.png" },
      { name: "Ethiopia", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/et.png" },
      { name: "Croatia", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/hr.png" },
      { name: "Hungary", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/hu.png" },
      { name: "Italy", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/it.png" },
      { name: "Jamaica", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/jm.png" },
      { name: "Romania", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/ro.png" },
      { name: "Russia", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/ru.png" },
      { name: "United States", imageSrc: "https://play.nativescript.org/dist/assets/img/flags/us.png" },
    ],

    onItemTap: function (args) {
      console.log('Item with index: ' + args.index + ' tapped');
    },

    currentGeoLocation: null,

    enableLocationServices: function () {
      geoLocation.isEnabled().then(enabled => {
        if (!enabled) {
          geoLocation.enableLocationRequest().then(() => this.showLocation());
        } else {
          this.showLocation();
        }
      });
    },

    showLocation: function () {
      geoLocation.watchLocation(location => {
        this.currentGeoLocation = location;
      }, error => {
        alert(error);
      }, {
          desiredAccuracy: 3,
          updateDistance: 10,
          minimumUpdateTime: 1000 * 1
        });
    },

    onButtonTap: function () {
      console.log("Button was pressed");
    },

    mainContentText: "𝗢𝗹𝗮́, 𝗦𝗲𝗷𝗮 𝗯𝗲𝗺 𝘃𝗶𝗻𝗱𝗼 𝗮𝗼 𝗮𝗽𝗽 Farmácia CALEO para funcionários !! 𝗮𝗾𝘂𝗶 𝘃𝗰 𝗽𝗼𝗱𝗲𝗿𝗮́ 𝗰𝗮𝗱𝗮𝘀𝘁𝗿𝗮𝗿 𝘀𝗲𝘂𝘀 𝗽𝗿𝗼𝗱𝘂𝘁𝗼𝘀 𝗲 𝗲𝗻𝘃𝗶𝗮𝗿 𝗮𝗼 𝘀𝗲𝘂 𝘀𝗶𝘁𝗲 𝗱𝗮 𝗺𝗲𝗹𝗵𝗼𝗿 𝗺𝗮𝗻𝗲𝗶𝗿𝗮 𝗽𝗼𝘀𝘀𝗶́𝘃𝗲𝗹. "
      + "𝗗𝗲𝘀𝗲𝗻𝘃𝗼𝗹𝘃𝗶𝗱𝗼 𝗽𝗼𝗿 𝗟𝗲𝗼𝗻𝗮𝗿𝗱𝗼 𝗲 𝗖𝗮𝗺𝗶𝗹𝗮, !!",
    onOpenDrawerTap: function () {
      var sideDrawer = frameModule.Frame.topmost().getViewById("sideDrawer");
      sideDrawer.showDrawer();
    },
    onCloseDrawerTap: function () {
      var sideDrawer = frameModule.Frame.topmost().getViewById("sideDrawer");
      sideDrawer.closeDrawer();
    },

   


  });

  return viewModel;
}

module.exports = HomeViewModel;
